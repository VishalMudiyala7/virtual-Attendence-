Just run the program on a python editor.
Make sure the students picture path is updated before running.
